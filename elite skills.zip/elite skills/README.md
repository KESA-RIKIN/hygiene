# YourHack – Hackathon Landing Page

Modern, responsive, single-page hackathon site inspired by DUHacks 4.0. Built with Tailwind (CDN), a normal external stylesheet (`styles/main.css`), and vanilla JavaScript.

## Preview
- Open `index.html` in your browser.

## Customize
1. Event name, date and copy: edit `index.html` hero, about, timeline, prizes, sponsors, and team sections.
2. Global styles and utilities: edit `styles/main.css` (we moved inline styles there).
3. Countdown target: update the date in `scripts/main.js`:

```js
// scripts/main.js
const eventStartDateUtc = new Date('2025-02-22T09:00:00+05:30');
```

4. Contact info: update the footer email in `index.html`.
5. Sponsor logos: replace placeholder boxes in `#sponsors` with `<img>` tags or SVGs.

## Run locally
No build step required.

- Double click `index.html` or serve locally (recommended for smooth scroll and caching):

```bash
# Python 3
python -m http.server 5173
# Then open http://localhost:5173
```

On Windows PowerShell, you can also use:

```powershell
Start-Process http://localhost:5173; python -m http.server 5173
```

## Deploy
### GitHub Pages
1. Push this folder to a GitHub repo.
2. Settings → Pages → Source: `Deploy from a branch`, select `main` and `/ (root)`.

### Netlify
1. Drag-and-drop the folder on app.netlify.com or connect the repo.
2. Build command: none. Publish directory: project root.

### Vercel
1. Import project.
2. Framework preset: `Other`. Output directory: `.`

## Attribution
- Visual direction inspired by DUHacks. Reference: [`https://duhacks.tech/`](https://duhacks.tech/)


