(function initializeSiteInteractions() {
	'use strict';

	/**
	 * Configuration
	 * Adjust the event start date/time here.
	 */
	const eventStartDateUtc = new Date('2025-02-22T09:00:00+05:30');

	/**
	 * Utility to safely get element by id
	 */
	function getElementById(id) {
		return /** @type {HTMLElement|null} */ (document.getElementById(id));
	}

	/**
	 * Mobile navigation toggle
	 */
	(function setupMobileMenuToggle() {
		const menuButton = getElementById('mobileMenuBtn');
		const menuPanel = getElementById('mobileMenu');
		if (!menuButton || !menuPanel) return;

		menuButton.addEventListener('click', function handleMenuToggle() {
			menuPanel.classList.toggle('hidden');
		});
	})();

	/**
	 * Smooth scroll with header offset for in-page anchors
	 */
	(function setupSmoothScrollOffset() {
		const header = document.querySelector('header');
		const headerHeight = header ? header.getBoundingClientRect().height : 0;
		const anchorLinks = document.querySelectorAll('a[href^="#"]');

		anchorLinks.forEach(function addSmoothScroll(link) {
			link.addEventListener('click', function (evt) {
				const href = /** @type {HTMLAnchorElement} */ (evt.currentTarget).getAttribute('href');
				if (!href || href.length <= 1) return;
				const targetId = href.slice(1);
				const section = getElementById(targetId);
				if (!section) return;

				evt.preventDefault();
				const sectionTop = section.getBoundingClientRect().top + window.scrollY;
				window.scrollTo({ top: Math.max(sectionTop - headerHeight - 12, 0), behavior: 'smooth' });
			});
		});
	})();

	/**
	 * Countdown timer
	 */
	(function setupCountdown() {
		const daysEl = getElementById('dd');
		const hoursEl = getElementById('hh');
		const minutesEl = getElementById('mm');
		const secondsEl = getElementById('ss');
		if (!daysEl || !hoursEl || !minutesEl || !secondsEl) return;

		function pad(num) {
			return String(num).padStart(2, '0');
		}

		function updateCountdown() {
			const now = new Date();
			const distanceMs = eventStartDateUtc.getTime() - now.getTime();

			if (distanceMs <= 0) {
				daysEl.textContent = '00';
				hoursEl.textContent = '00';
				minutesEl.textContent = '00';
				secondsEl.textContent = '00';
				return;
			}

			const secondsTotal = Math.floor(distanceMs / 1000);
			const days = Math.floor(secondsTotal / (3600 * 24));
			const hours = Math.floor((secondsTotal % (3600 * 24)) / 3600);
			const minutes = Math.floor((secondsTotal % 3600) / 60);
			const seconds = secondsTotal % 60;

			daysEl.textContent = pad(days);
			hoursEl.textContent = pad(hours);
			minutesEl.textContent = pad(minutes);
			secondsEl.textContent = pad(seconds);
		}

		updateCountdown();
		setInterval(updateCountdown, 1000);
	})();

	/**
	 * Dynamic copyright year
	 */
	(function setYear() {
		const yearEl = getElementById('year');
		if (yearEl) {
			yearEl.textContent = String(new Date().getFullYear());
		}
	})();
})();


